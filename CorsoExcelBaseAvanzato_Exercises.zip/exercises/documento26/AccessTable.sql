CREATE TABLE NomiPersone (
    ID INT PRIMARY KEY,
    Nome VARCHAR(50),
    Cognome VARCHAR(50),
    DataNascita DATE,
    Indirizzo VARCHAR(100),
    Città VARCHAR(50),
    CAP VARCHAR(10)
);